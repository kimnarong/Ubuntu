#!/usr/bin/python
# -*- coding: utf8 -*-

import rospy
from geometry_msgs.msg import Twist

class MyTurtle:
    def __init__(self):
        self.sub = rospy.Subscriber("cmd_vel",Twist,self.msgCallback)
        self.pub = rospy.Publisher("turtle1/cmd_vel",Twist,queue_size=1)


   #메세지가 들어왔을 때 실행 할 메세지 콜백 함수 만들어 주기
    def msgCallback(self,msg): 
        self.pub.publish(msg)
        if msg.linear.z > 0:
            print("t")
        elif msg.linear.z < 0:
            print("b")

            #받아서 사용 할 퍼블리셔 함수
if __name__=="__main__":
    rospy.init_node("yh_turtle_keyboard_pen")
    my_turtle = MyTurtle()
    rospy.spin()
